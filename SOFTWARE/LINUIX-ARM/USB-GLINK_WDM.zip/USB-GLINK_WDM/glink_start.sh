#!/bin/bash

source <(grep = settings.ini)

#Find cdc device
DEV=$(ls /dev/cdc-wdm*)
[[ -z $DEV ]] && echo "Couldn't find cdc-wdm device" && exit 1

#Get Interface by cdc device name
IFACE=$(sudo qmicli --device=$DEV --device-open-proxy --get-wwan-iface)
[[ -z $IFACE ]] && echo  "No interface found for $DEV"  && exit 1


echo "IFACE=$IFACE"
echo "DEV=$DEV"

qmicli --device=$DEV -p --dms-uim-verify-pin=PIN,$SIM_PIN

sudo ip link set dev $IFACE down
echo "Y" | sudo tee /sys/class/net/$IFACE/qmi/raw_ip > /dev/null
sudo ip link set dev $IFACE up
qmicli --device=$DEV --device-open-proxy --wds-start-network="ip-type=4,apn=$APN" --client-no-release-cid

sudo udhcpc -q -f -n -i $IFACE

dns-fix
