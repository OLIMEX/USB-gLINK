#!/bin/bash

REQUIRED_PACKAGES=(libqmi-utils udhcpc)
INSTALL_LIST=()
for package in ${REQUIRED_PACKAGES[@]}; do
    dpkg -l | grep -w $package > /dev/null 2>&1 || \
    INSTALL_LIST+=($package)
done

if [[ ! -z $INSTALL_LIST ]];
	then
		echo "=============== INSTALLING APPS: ================="
		echo ""
		sudo apt update > /dev/null 2>&1
		
		for package in ${INSTALL_LIST[@]}; do
			echo -n "Installing $package.................."
			sudo apt install -y $package > /dev/null 2>&1 && \
			echo -e "$GREEN[DONE]$RESET" && continue
			echo -e "$RED[FAILED]$RESET" && echo "Failed to install $package" >> ./Installation.LOG && exit 1
		done

fi

sudo mkdir /opt/usb-glink
sudo cp ./glink_start.sh /opt/usb-glink
sudo cp ./settings.ini /opt/usb-glink
sudo cp ./99-glink_start.rules /etc/udev/rules.d/  



